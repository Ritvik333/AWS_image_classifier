import json
import boto3
import uuid
import base64
import os
from datetime import datetime

# AWS clients
s3_client = boto3.client('s3')
sqs_client = boto3.client('sqs')
dynamodb = boto3.resource('dynamodb')

# Configuration (set as environment variables in Lambda)
S3_BUCKET = os.environ['S3_BUCKET']  # e.g., 'my-image-recognition-bucket'
SQS_QUEUE_URL = os.environ['SQS_QUEUE_URL']  # e.g., 'https://sqs.<region>.amazonaws.com/<account-id>/image-processing-queue'
DYNAMODB_TABLE = os.environ['DYNAMODB_TABLE']  # e.g., 'ImageRecognitionTasks'

def lambda_handler(event, context):
    """Handle image upload, validate, store in S3, and queue task in SQS."""
    try:
        # Parse the API Gateway event
        body = json.loads(event.get('body', '{}'))
        image_data = body.get('image')  # Base64-encoded image
        file_name = body.get('file_name', f'image_{uuid.uuid4()}.jpg')

        if not image_data or not file_name.lower().endswith(('.png', '.jpg', '.jpeg')):
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Invalid image or file format'})
            }

        # Decode base64 image
        image_bytes = base64.b64decode(image_data)

        # Generate unique task ID
        task_id = str(uuid.uuid4())

        # Upload image to S3
        s3_client.put_object(
            Bucket=S3_BUCKET,
            Key=f'uploads/{file_name}',
            Body=image_bytes
        )
        print(f"Uploaded {file_name} to S3 bucket {S3_BUCKET}")  # Logged to CloudWatch

        # Store metadata in DynamoDB
        table = dynamodb.Table(DYNAMODB_TABLE)
        table.put_item(
            Item={
                'TaskId': task_id,
                'FileName': file_name,
                'Status': 'QUEUED',
                'SubmissionTime': datetime.utcnow().isoformat()
            }
        )
        print(f"Stored metadata for task {task_id} in DynamoDB")  # Logged to CloudWatch

        # Send message to SQS
        message_body = json.dumps({
            'TaskId': task_id,
            'FileName': file_name,
            'S3Bucket': S3_BUCKET
        })
        sqs_client.send_message(
            QueueUrl=SQS_QUEUE_URL,
            MessageBody=message_body
        )
        print(f"Queued task {task_id} in SQS")  # Logged to CloudWatch

        return {
            'statusCode': 200,
            'body': json.dumps({'task_id': task_id, 'message': 'Image queued for processing'})
        }

    except Exception as e:
        print(f"Error: {str(e)}")  # Logged to CloudWatch
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }